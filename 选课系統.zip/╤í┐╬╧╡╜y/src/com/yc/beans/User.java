package com.yc.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class User implements Serializable,Comparable<User>{

	private String username;
	private String password;
	private Set<Custom> set=new TreeSet<Custom>();
	
	
	public Set<Custom> getSet() {
		return set;
	}
	public void setSet(Set<Custom> set) {
		this.set = set;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		User user=(User) obj;
		return username.equals(user.username)&&password.equals(user.password);
	}
	public User(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + "]";
	}
	@Override
	public int compareTo(User o) {
		int compareTo = username.compareTo(o.username);
		if (compareTo==0) {
			compareTo=password.compareTo(o.password);
		}
		return compareTo;
	}
	
}
