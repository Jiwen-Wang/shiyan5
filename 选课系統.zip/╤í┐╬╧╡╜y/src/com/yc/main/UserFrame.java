package com.yc.main;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import com.yc.beans.Custom;
import com.yc.beans.User;


public class UserFrame extends JFrame{


	File file =new File("objs.txt");
	List<Custom> list=new ArrayList<Custom>();
	private final Integer WIDTH=600,HEIGHT=400;
	private JTable jTable;
	public UserFrame(User user) {
		File f = new File("users.obj");
		Set<User> users = null;
		if (!f.exists()) {
			users = new TreeSet<>();
			try {
				ObjectOutputStream objectOutputStream= new ObjectOutputStream(
						new FileOutputStream(f));
				objectOutputStream.writeObject(users);
				objectOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else {
			try {
				ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(f));
				users = (Set<User>)objectInputStream.readObject();
				objectInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		for (User u : users) {
			if (user.equals(u)) {
				user=u;
				break;
			}
		}
		
		
		final User onlineUser=user;
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(((int)screenSize.getWidth()-WIDTH)/2, ((int)screenSize.getHeight()-HEIGHT)/2,WIDTH,HEIGHT);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				
				
				
				Set<User> users = null;
				if (!f.exists()) {
					users = new TreeSet<>();
					try {
						ObjectOutputStream objectOutputStream= new ObjectOutputStream(
								new FileOutputStream(f));
						objectOutputStream.writeObject(users);
						objectOutputStream.close();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}else {
					try {
						ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(f));
						users = (Set<User>)objectInputStream.readObject();
						objectInputStream.close();
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}
				users.add(onlineUser);
				UserFrame.this.dispose();
			}
		});
		jTable = new JTable();
		jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jScrollPane = new javax.swing.JScrollPane();
		jScrollPane.setViewportView(jTable);
		
		flush(list, jTable);
		add(jScrollPane);
		
		JPanel southPanel = new JPanel();
		
		JButton xkBtn = new JButton("ѡ��");
		xkBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int row = jTable.getSelectedRow();
				if (row!=-1) {
					if (!onlineUser.getSet().add(list.get(row))) {
						JOptionPane.showMessageDialog(UserFrame.this, "�����ظ�ѡ��");
						return;
					}
				}else {
					JOptionPane.showMessageDialog(UserFrame.this, "��ѡ��һ��");
				}
			}
		});
		southPanel.add(xkBtn);
		
		
		JButton print = new JButton("��ӡѡ��");
		print.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String path=onlineUser.getUsername()+".txt";
				File f = new File(path);
				try {
					PrintStream printStream = new PrintStream(f);
					printStream.println("ѧ����"+onlineUser.getUsername()+"    ѡ����Ϣ��");
					Set<Custom> set = onlineUser.getSet();
					for (Custom custom : set) {
						printStream.println(custom);
					}
					printStream.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		southPanel.add(print);
		add(southPanel,BorderLayout.SOUTH);
		
		setVisible(true);
	}
	public synchronized static void update(List<Custom> list) {
		
		try {
			ObjectOutputStream objectOutputStream= new ObjectOutputStream(
					new FileOutputStream("objs.txt"));
			objectOutputStream.writeObject(list);
			objectOutputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public  static void flush(List<Custom> list,JTable jTable) {
		try {
			ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("objs.txt"));
			list.clear();;
			for (Custom custom : (List<Custom>)objectInputStream.readObject()) {
				list.add(custom);
				System.out.println(custom);
			}
			objectInputStream.close();
			String[][] date=new String[list.size()][5];
			for (int i = 0; i < list.size(); i++) {
				date[i][0]=list.get(i).getName();
				date[i][1]=list.get(i).getTeacher()+"";
				date[i][2]=list.get(i).getDate()+"";
			}
			DefaultTableModel md = new DefaultTableModel(date, new String[] {"�γ�����","��ʦ","ʱ��"});
			jTable.setModel(md);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new UserFrame(null);
	}
}
