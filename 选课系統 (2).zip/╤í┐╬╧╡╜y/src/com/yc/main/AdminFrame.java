package com.yc.main;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import com.yc.beans.Custom;
import com.yc.beans.User;


public class AdminFrame extends JFrame{

	
	File file =new File("objs.txt");
	List<Custom> list=new ArrayList<Custom>();
	private final Integer WIDTH=600,HEIGHT=400;
	private JTable jTable;
	private Set<User> users;
	public AdminFrame() {
		File f = new File("users.obj");
		if (!f.exists()) {
			System.out.println("������");
			users = new TreeSet<>();
			try {
				ObjectOutputStream objectOutputStream= new ObjectOutputStream(
						new FileOutputStream(f));
				objectOutputStream.writeObject(users);
				objectOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else {
			try {
				ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(f));
				users = (Set<User>)objectInputStream.readObject();
				System.out.println("user=========="+users);
				objectInputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("user=========="+users);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(((int)screenSize.getWidth()-WIDTH)/2, ((int)screenSize.getHeight()-HEIGHT)/2,WIDTH,HEIGHT);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				AdminFrame.this.dispose();
			}
		});
		jTable = new JTable();
		jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jScrollPane = new javax.swing.JScrollPane();
		jScrollPane.setViewportView(jTable);
		
		flush(list, jTable);
		add(jScrollPane);
		
		JPanel southPanel = new JPanel();
		add(southPanel,BorderLayout.SOUTH);
		JButton insertBtn = new JButton("����");
		insertBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JDialog jDialog = new JDialog();
				jDialog.setBounds(AdminFrame.this.getX(), AdminFrame.this.getY(), WIDTH/2, (int)(HEIGHT*0.75));
				jDialog.setLayout(new GridLayout(6, 2));
				jDialog.add(new JLabel("�γ�����",JLabel.CENTER));
				TextField name = new TextField("java");
				jDialog.add(name);
				jDialog.add(new JLabel("��ʦ",JLabel.CENTER));
				TextField teacher = new TextField("��ʦ");
				jDialog.add(teacher);
				jDialog.add(new JLabel("ʱ��",JLabel.CENTER));
				TextField date = new TextField("2020-1-1 1:1:1");
				jDialog.add(date);
				JButton ok = new JButton("����");
				ok.addActionListener(new ActionListener() {
					

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						try {
							Custom custom = new Custom(name.getText().trim(), teacher.getText().trim(), date.getText().trim());
							list.add(custom);
							update(list);
							jDialog.setVisible(false);
							flush(list, jTable);
						} catch (Exception e1) {
							e1.printStackTrace();
							JOptionPane.showMessageDialog(AdminFrame.this, "��ʽ����ȷ��");
						}
					}

					
				});
				jDialog.add(ok);
				
				
				JButton cancel = new JButton("ȡ��");
				cancel.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						jDialog.setVisible(false);
					}
				});
				jDialog.add(cancel);
				jDialog.setVisible(true);
			}
		});
		southPanel.add(insertBtn);
		JButton deleteBtn = new JButton("ɾ��");
		deleteBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int row = jTable.getSelectedRow();
				if (row!=-1) {
					list.remove(row);
					try {
						update(list);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					flush(list, jTable);
				}else {
					JOptionPane.showMessageDialog(AdminFrame.this, "��ѡ��һ��");
				}
			}
		});
		southPanel.add(deleteBtn);
		
		JButton update = new JButton("����");
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				int row = jTable.getSelectedRow();
				if (row!=-1) {
					

					Custom custom = list.get(row);

					JDialog jDialog = new JDialog();
					jDialog.setBounds(AdminFrame.this.getX(), AdminFrame.this.getY(), WIDTH/2, (int)(HEIGHT*0.75));
					jDialog.setLayout(new GridLayout(6, 2));
					jDialog.add(new JLabel("�γ�����",JLabel.CENTER));
					TextField name = new TextField(custom.getName());
					jDialog.add(name);
					jDialog.add(new JLabel("��ʦ",JLabel.CENTER));
					TextField teacher = new TextField(custom.getTeacher());
					jDialog.add(teacher);
					jDialog.add(new JLabel("ʱ��",JLabel.CENTER));
					TextField date = new TextField(custom.getDate());
					jDialog.add(date);
					JButton ok = new JButton("����");
					ok.addActionListener(new ActionListener() {
						

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							try {
								Custom custom = new Custom(name.getText().trim(), teacher.getText().trim(), date.getText().trim());
								list.set(row, custom);
								update(list);
								jDialog.setVisible(false);
								flush(list, jTable);
							} catch (Exception e1) {
								e1.printStackTrace();
								JOptionPane.showMessageDialog(AdminFrame.this, "��ʽ����ȷ��");
							}
						}

						
					});
					jDialog.add(ok);
					
					
					JButton cancel = new JButton("ȡ��");
					cancel.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							jDialog.setVisible(false);
						}
					});
					jDialog.add(cancel);
					jDialog.setVisible(true);
					
					
					
					
					
					
//					list.remove(row);
					try {
						update(list);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					flush(list, jTable);
				}else {
					JOptionPane.showMessageDialog(AdminFrame.this, "��ѡ��һ��");
				}
			}
			
		});
		southPanel.add(update);
		
		JButton print = new JButton("��ӡѡ��");
		print.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					PrintStream printStream = new PrintStream("����ѧ����ѡ����Ϣ.txt");
					System.out.println("user............."+users);
					for(User user: users) {
						printStream.println("ѧ����"+user.getUsername()+"    ѡ����Ϣ��");
						Set<Custom> set = user.getSet();
						for (Custom custom : set) {
							printStream.println(custom);
						}
						printStream.println("---------------------------------------");
					}
					printStream.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		southPanel.add(print);
		
		setVisible(true);
	}
	public synchronized static void update(List<Custom> list) {
		
		try {
			ObjectOutputStream objectOutputStream= new ObjectOutputStream(
					new FileOutputStream("objs.txt"));
			objectOutputStream.writeObject(list);
			objectOutputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public  static void flush(List<Custom> list,JTable jTable) {
		try {
			ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("objs.txt"));
			list.clear();;
			for (Custom custom : (List<Custom>)objectInputStream.readObject()) {
				list.add(custom);
				System.out.println(custom);
			}
			objectInputStream.close();
			String[][] date=new String[list.size()][5];
			for (int i = 0; i < list.size(); i++) {
				date[i][0]=list.get(i).getName();
				date[i][1]=list.get(i).getTeacher()+"";
				date[i][2]=list.get(i).getDate()+"";
			}
			DefaultTableModel md = new DefaultTableModel(date, new String[] {"�γ�����","��ʦ","ʱ��"});
			jTable.setModel(md);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new AdminFrame();
	}
}
