package com.yc.main;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.yc.beans.User;


public class Main extends JFrame{

	private final Integer WIDTH=600,HEIGHT=400;
	public Main() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(((int)screenSize.getWidth()-WIDTH)/2, ((int)screenSize.getHeight()-HEIGHT)/2,WIDTH,HEIGHT);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		//TODO
		setLayout(new FlowLayout(FlowLayout.CENTER, 50, 150));
		JButton adminBtn = new JButton("����Ա");
		adminBtn.addActionListener(new ActionListener() {
			private AdminFrame adminFrame;
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

		        if (adminFrame==null) {
		        	final JFrame loginFrame = new JFrame();
					loginFrame.setState(JFrame.EXIT_ON_CLOSE);
					loginFrame.setBounds(200, 150, 400, 300);
					loginFrame.setLayout(new GridLayout(2, 1));
					Label loginLabel = new Label("Login",Label.CENTER);
					loginLabel.setFont(new Font("", 1, 30));
					loginFrame.add(loginLabel);
					Panel panel = new Panel();
					panel.add(new Label("username:"));
					final TextField username = new TextField(35);
					panel.add(username);
					panel.add(new Label("password:"));
					final TextField password = new TextField(35);
					panel.add(password);
					Button loginButton = new Button("login");
					panel.add(loginButton);
					loginButton.addActionListener(new ActionListener() {
						

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							String name = username.getText().trim();
							String pwd = password.getText().trim();
							System.out.println(name+":"+pwd);
							if ("".equals(name)||"".equals(pwd)) {
								JOptionPane.showMessageDialog(loginFrame, "�û���������Ϊ�գ����������룡");
							}else {
								User user = new User(name,pwd);
								if (user.getUsername().equals("admin")&&user.getPassword().equals("admin")) {
									loginFrame.setVisible(false);
									System.out.println("��¼�ɹ�");
									adminFrame = new AdminFrame();
									return;
								}
								JOptionPane.showMessageDialog(loginFrame, "�û���������������������룡");
							}
						}
					});
					loginFrame.add(panel);
					loginFrame.setVisible(true);
				}else {
					adminFrame.setVisible(true);
				}
			
			}
		});
		add(adminBtn);
		JButton userBtn = new JButton("�û�");
		userBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread() {
					public void run() {
						login();
					};
				}.start();
			}
		});
		add(userBtn);
		setVisible(true);
	}
	public void login() {
        final JFrame loginFrame = new JFrame();
		loginFrame.setState(JFrame.EXIT_ON_CLOSE);
		loginFrame.setBounds(200, 150, 400, 300);
		loginFrame.setLayout(new GridLayout(2, 1));
		Label loginLabel = new Label("Login",Label.CENTER);
		loginLabel.setFont(new Font("", 1, 30));
		loginFrame.add(loginLabel);
		Panel panel = new Panel();
		panel.add(new Label("username:"));
		final TextField username = new TextField(35);
		panel.add(username);
		panel.add(new Label("password:"));
		final TextField password = new TextField(35);
		panel.add(password);
		Button loginButton = new Button("login");
		panel.add(loginButton);
		loginButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String name = username.getText().trim();
				String pwd = password.getText().trim();
				System.out.println(name+":"+pwd);
				if ("".equals(name)||"".equals(pwd)) {
					JOptionPane.showMessageDialog(loginFrame, "�û���������Ϊ�գ����������룡");
				}else {
					User user = new User(name,pwd);
					java.util.List<User> list = read();
					for (User u : list) {
						if (u.equals(user)) {
							loginFrame.setVisible(false);
							System.out.println("��¼�ɹ�");
							new UserFrame(u);
							return;
						}
					}
					JOptionPane.showMessageDialog(loginFrame, "�û���������������������룡");
				}
			}
		});
		loginFrame.add(panel);
		loginFrame.setVisible(true);
	}
	@SuppressWarnings("resource")
	public List<User> read() {
		List<User> list = new ArrayList<User>();
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader("users.txt"));
			while (bufferedReader.ready()) {
				String[] split = bufferedReader.readLine().split(" +");
				list.add(new User(split[0], split[1]));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public static void main(String[] args) {
		new Main();
	}
}
