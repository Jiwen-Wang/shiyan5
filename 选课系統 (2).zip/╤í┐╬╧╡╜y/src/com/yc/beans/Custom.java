package com.yc.beans;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Custom implements Serializable,Comparable<Custom>{

	static final long serialVersionUID = 42L;
	public static SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:dd");
	private String name;
	private String teacher;
	@Override
	public String toString() {
		return "Custom [name=" + name + ", teacher=" + teacher + ", date=" + date + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getDate() {
		return simpleDateFormat.format(date);
	}
	public void setDate(Date date) {
		this.date = date;
	}
	private Date date;
	public Custom(String name, String teacher, String date) {
		super();
		this.name = name;
		this.teacher = teacher;
		try {
			this.date = simpleDateFormat.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public int compareTo(Custom o) {
		int compareTo = name.compareTo(o.name);
		if (compareTo==0) {
			compareTo=teacher.compareTo(o.teacher);
			if (compareTo==0) {
				compareTo=date.compareTo(o.date);
			}
		}
		return compareTo;
	}
	
}
